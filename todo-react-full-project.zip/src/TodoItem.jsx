import { useState } from "react";

function TodoItem({ todo, toggleTodo, deleteTodo, editTodo }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(todo.text);

  return (
    <li>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => toggleTodo(todo.id)}
      />

      {editing ? (
        <input value={text} onChange={e => setText(e.target.value)} />
      ) : (
        <span style={{ textDecoration: todo.completed ? "line-through" : "" }}>
          {todo.text}
        </span>
      )}

      {editing ? (
        <button onClick={() => { editTodo(todo.id, text); setEditing(false); }}>
          שמור
        </button>
      ) : (
        <button onClick={() => setEditing(true)}>ערוך</button>
      )}

      <button onClick={() => deleteTodo(todo.id)}>מחק</button>
    </li>
  );
}

export default TodoItem;