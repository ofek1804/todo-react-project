import { useState } from "react";

function TodoInput({ addTodo }) {
  const [text, setText] = useState("");

  const submit = () => {
    if (!text.trim()) return;
    addTodo(text);
    setText("");
  };

  return (
    <div>
      <input value={text} onChange={e => setText(e.target.value)} />
      <button onClick={submit}>הוסף</button>
    </div>
  );
}

export default TodoInput;