function FilterButtons({ setFilter }) {
  return (
    <div>
      <button onClick={() => setFilter("all")}>הכל</button>
      <button onClick={() => setFilter("active")}>פעיל</button>
      <button onClick={() => setFilter("completed")}>הושלם</button>
    </div>
  );
}

export default FilterButtons;